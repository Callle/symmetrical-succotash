//db.js

const { Sequelize, DataTypes } = require('sequelize');

// Setup a new Sequelize instance
const sequelize = new Sequelize(process.env.DB_DATABASE, process.env.DB_USER, process.env.DB_PASSWORD , {
  host: process.env.DB_HOST,
  dialect: 'mysql'
});

const User = sequelize.define('User', {
  username: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false
  },
  ip: {
    type: DataTypes.STRING
  },
  referrer_id: {
    type: DataTypes.INTEGER,
    references: { // this is the reference to another model
      model: 'users', // this is a key value pair, the key is the name of this model
      key: 'id', // the key field of the model that we're referencing
    }
  }
}, {
  tableName: 'users',
  charset: 'utf8mb4',
  collate: 'utf8mb4_general_ci',
  timestamps: true,
});

User.belongsTo(User, { as: 'referrer', foreignKey: 'referrer_id' });

module.exports = { sequelize, User };
