// app.js

require('dotenv').config();

const express = require('express');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const rateLimit = require("express-rate-limit");
const { sequelize, User } = require('./db');
const app = express();
const port = 3000;

const tutorialVideos = [
  process.env.TIER1_VIDEOS.split(','),
  process.env.TIER2_VIDEOS.split(','),
  process.env.TIER3_VIDEOS.split(','),
  process.env.TIER4_VIDEOS.split(','),
  process.env.TIER5_VIDEOS.split(',')
];

app.use(cors());
app.use(express.json());
// app.use(rateLimit({
//   windowMs: 5 * 60 * 1000, // 5 minutes
//   max: 100 // limit each IP to 100 requests per windowMs
// }));

sequelize.sync({ alter: false })
  .then(() => {
    console.log('Database & tables created!');
  })
  .catch(error => {
    console.error('Unable to connect to the database:', error);
  });

app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;

  try {
    const user = await User.findOne({ where: { username } });
    if (!user || !bcrypt.compareSync(password, user.password)) {
      return res.status(401).json({ message: 'Invalid username or password' });
    }
    const token = jwt.sign({ id: user.id, username: user.username }, process.env.JWT_SECRET);
    res.json({ id: user.id, username: user.username, token });
  } catch (error) {
    return res.status(500).json({ error });
  }
});

const createAccountLimiter = rateLimit({
  windowMs: 60 * 2000, // 2 minute window
  max: 8, // start blocking after 5 requests
  message: "Too many accounts created from this IP, please try again after two minutes"
});

app.post('/api/register', createAccountLimiter, async (req, res) => {
    const { username, password, inviteCode, ip } = req.body;
  
    // Check if the username and password meet the requirements
    if (username.length < 4) {
      return res.status(400).json({ message: 'Username must be at least 4 characters long.' });
    }
    if (password.length < 6) {
      return res.status(400).json({ message: 'Password must be at least 6 characters long.' });
    }
  
    // Check if the invite code corresponds to an existing user
    if (inviteCode) { // This will return false if inviteCode is null, undefined or an empty string
      const referrer = await User.findOne({ where: { id: inviteCode } });
      if (!referrer) {
        return res.status(400).json({ message: 'Invalid invite code.' });
      }
    }
  
    // Check if the username already exists
    const existingUser = await User.findOne({ where: { username } });
    if (existingUser) {
      return res.status(400).json({ message: 'This username is already taken.' });
    }

    // Hash the password and insert the new user into the database
    const hashedPassword = bcrypt.hashSync(password, 10);

    try {
      const newUser = await User.create({
        username,
        password: hashedPassword,
        ip,
        referrer_id: inviteCode
      });

      const token = jwt.sign({ id: newUser.id, username }, process.env.JWT_SECRET);
      res.status(201).json({ id: newUser.id, username, token });
    } catch (error) {
      return res.status(500).json({ error });
    }
  });
  
  app.get('/api/dashboard/:userId', async (req, res) => {
    const userId = req.params.userId;
  
    try {
      // Fetch invited users and their IDs
      const invitedUsers = await User.findAll({ where: { referrer_id: userId }, attributes: ['username'] });
      const totalInvites = invitedUsers.length;
  
      // Calculate the user's tier based on the total invites
      let tier = 1;
      if (totalInvites >= 20) {
        tier = 5;
      } else if (totalInvites >= 15) {
        tier = 4;
      } else if (totalInvites >= 10) {
        tier = 3;
      } else if (totalInvites >= 5) {
        tier = 2;
      }
  
      res.json({
        tier,
        totalInvites,
        invitedUsers,
      });
    } catch (error) {
      return res.status(500).json({ error });
    }
  });

  app.get('/api/videos/:tier', (req, res) => {
    const tier = req.params.tier;
    if (tier < 1 || tier > 5) {
      res.status(400).json({ error: 'Invalid tier' });
    } else {
      res.json({ videos: tutorialVideos[tier - 1] });
    }
  });

  app.get('/api/videos', async (req, res) => {
    const { userId, tier } = req.query;
  
    try {
      const user = await User.findOne({ where: { id: userId } });
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
  
      const invitedUsers = await User.findAll({ where: { referrer_id: userId } });
      const totalInvites = invitedUsers.length;
  
      let userTier = 1;
      if (totalInvites >= 20) {
        userTier = 5;
      } else if (totalInvites >= 15) {
        userTier = 4;
      } else if (totalInvites >= 10) {
        userTier = 3;
      } else if (totalInvites >= 5) {
        userTier = 2;
      }
  
      if (userTier < tier) {
        return res.status(403).json({ message: 'You do not have access to this tier' });
      }
  
      const videos = tutorialVideos[tier - 1];
  
      res.json({ videos });
    } catch (error) {
      return res.status(500).json({ error });
    }
  });
  
  app.get('/api/generate-invite-link/:userId', (req, res) => {
    res.json({ inviteLink: `http://localhost:4200/r/${req.params.userId}` });
  });

  app.get('/api/registration-log', async (req, res) => {
    try {
      const users = await User.findAll({
        order: [['createdAt', 'DESC']],
        limit: 40,
        include: {
          model: User,
          as: 'referrer',
          attributes: ['id', 'username'],
        },
      });
  
      const templates = [
        (user, referrer, totalInvites, tierChange) => `<span class="highlight">${tierChange}</span> <span class="highlight">${user.username}</span> just registered, invited by ${referrer ? `<span class="highlight">${referrer.username}</span>` : 'N/A'}. ${referrer ? `<span class="highlight">${referrer.username}</span> now has <span class="highlight">${totalInvites}</span> invites.` : ''}`,
        (user, referrer, totalInvites, tierChange) => `<span class="highlight">${tierChange}</span> <span class="highlight">${user.username}</span> has just joined us thanks to ${referrer ? `<span class="highlight">${referrer.username}'s</span> invite. <span class="highlight">${referrer.username}'s</span> invite count is now <span class="highlight">${totalInvites}</span>.` : ''}`,
        (user, referrer, totalInvites, tierChange) => `<span class="highlight">${tierChange}</span> Woah! <span class="highlight">${user.username}</span> has just registered, brought in by ${referrer ? `<span class="highlight">${referrer.username}</span>. <span class="highlight">${referrer.username}'s</span> invite count just went up to <span class="highlight">${totalInvites}</span>.` : ''}`,
        (user, referrer, totalInvites, tierChange) => `<span class="highlight">${tierChange}</span> Oh shit! <span class="highlight">${user.username}</span> registered. ${referrer ? `<span class="highlight">${referrer.username}</span> now has <span class="highlight">${totalInvites}</span> invites.` : ''}`,
        (user, referrer, totalInvites, tierChange) => `<span class="highlight">${tierChange}</span> Uh-oh, <span class="highlight">${user.username}</span> just registered. ${referrer ? `<span class="highlight">${referrer.username}</span> you're now on <span class="highlight">${totalInvites}</span> invites..` : ''}`,
        (user, referrer, totalInvites, tierChange) => `<span class="highlight">${tierChange}</span> <span class="highlight">${user.username}</span> has just popped in, all thanks to ${referrer ? `<span class="highlight">${referrer.username}</span>. Looks like <span class="highlight">${referrer.username}</span> has notched up to <span class="highlight">${totalInvites}</span> invites.` : ''}`,
        (user, referrer, totalInvites, tierChange) => `<span class="highlight">${tierChange}</span> Surprise! <span class="highlight">${user.username}</span> is our newest member. Kudos to ${referrer ? `<span class="highlight">${referrer.username}</span> who's invite tally now stands at <span class="highlight">${totalInvites}</span>.` : ''}`,
        (user, referrer, totalInvites, tierChange) => `<span class="highlight">${tierChange}</span> Hold on, <span class="highlight">${user.username}</span> has jumped aboard. ${referrer ? `Big shoutout to <span class="highlight">${referrer.username}</span> whose invite count has climbed to <span class="highlight">${totalInvites}</span>.` : ''}`,
        (user, referrer, totalInvites, tierChange) => `<span class="highlight">${tierChange}</span> Heads up! <span class="highlight">${user.username}</span> has swooped into our ranks. Props to ${referrer ? `<span class="highlight">${referrer.username}</span> as their invites pile up to <span class="highlight">${totalInvites}</span>.` : ''}`,
        (user, referrer, totalInvites, tierChange) => `<span class="highlight">${tierChange}</span> Guess what! <span class="highlight">${user.username}</span> is the latest to join the party. Hats off to ${referrer ? `<span class="highlight">${referrer.username}</span> whose tally of invites is now a cool <span class="highlight">${totalInvites}</span>.` : ''}`,
      ];
  
      const log = await Promise.all(users.map(async (user) => {
        const referrer = user.referrer;
        let totalInvites = 0;
        let userTier = 1;
        let tierChange = '';
  
        if (referrer && referrer.id) {
          totalInvites = await User.count({ where: { referrer_id: referrer.id } });
          if (totalInvites >= 20) {
            userTier = 5;
          } else if (totalInvites >= 15) {
            userTier = 4;
          } else if (totalInvites >= 10) {
            userTier = 3;
          } else if (totalInvites >= 5) {
            userTier = 2;
          }
  
          if (totalInvites % 5 === 0 && totalInvites > 0 && totalInvites < 6) {
            tierChange = `<h3>${referrer.username}, JUST UNLOCKED TIER ${userTier} CONTENT FOR FREE!</h3>`;
          }
        }
  
        const template = templates[Math.floor(Math.random() * templates.length)];
        const message = template(user, referrer, totalInvites, tierChange);
  
        return { message, timestamp: user.createdAt, totalInvites, userTier };
      }));
  
      res.json({ log });
    } catch (error) {
      console.error(error);
      return res.status(500).json({ error });
    }
  });

  app.listen(port, () => {
    console.log(`Server listening at http://localhost:${port}/api`);
  });