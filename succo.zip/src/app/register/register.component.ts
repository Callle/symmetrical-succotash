// register.component.ts

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { AuthService } from '../auth.service';
import { Validators } from '@angular/forms';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  username = '';
  password = '';
  inviteCode = '';
  inviteCodeDisabled: boolean = false;
  errorMessage = '';

  constructor(private authService: AuthService, private router: Router, private http: HttpClient, private route: ActivatedRoute, private activatedRoute: ActivatedRoute) {}

  ngOnInit(): void {
    this.activatedRoute.params.subscribe((params: any) => {
      this.inviteCode = params['inviteCode'] || '';
      this.inviteCodeDisabled = !!this.inviteCode;
    });
  }

  register(): void {
    if (this.username.length < 4 || this.password.length < 6) {
      alert('Username must be at least 4 characters long and password must be at least 6 characters long.');
      return;
    }
    this.http.get(environment.ipUrl).subscribe((res: any) => {
      const userIP = res.ip;
      this.authService.register(this.username, this.password, this.inviteCode, userIP).subscribe(
        data => {
          this.authService.storeUser(data);
          this.router.navigate(['/dashboard']);
        },
        error => {
          console.log('Error', error);
          this.errorMessage = error;
        }
      );
    });
  }
 }
