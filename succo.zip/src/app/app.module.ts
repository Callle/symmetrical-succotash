// app.module.ts

import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SafePipe } from './safe.pipe';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { WelcomeComponent } from './dashboard/welcome/welcome.component';
import { BuyTiersComponent } from './dashboard/buy-tiers/buy-tiers.component';
import { FaqComponent } from './dashboard/faq/faq.component';
import { TierComponent } from './dashboard/tier/tier.component';
import { Tier1Component } from './dashboard/tier1/tier1.component';
import { Tier2Component } from './dashboard/tier2/tier2.component';
import { Tier3Component } from './dashboard/tier3/tier3.component';
import { Tier4Component } from './dashboard/tier4/tier4.component';
import { Tier5Component } from './dashboard/tier5/tier5.component';
import { ReferralLogComponent } from './dashboard/referral-log/referral-log.component';

// Angular Material Components
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatExpansionModule } from '@angular/material/expansion';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    DashboardComponent,
    NotFoundComponent,
    BuyTiersComponent,
    FaqComponent,
    Tier1Component,
    Tier2Component,
    Tier3Component,
    Tier4Component,
    Tier5Component,
    ReferralLogComponent,
    WelcomeComponent,
    TierComponent,
    SafePipe,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatToolbarModule,
    MatButtonModule,
    MatIconModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatListModule,
    MatSidenavModule,
    MatExpansionModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }