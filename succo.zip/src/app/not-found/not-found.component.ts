// not-found.component.ts
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-not-found',
  templateUrl: './not-found.component.html',
  styleUrls: ['./not-found.component.css']
})
export class NotFoundComponent implements OnInit {
  errorCode = '404';
  errorMessage = 'Page Not Found';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    // Get the error code and message from the route data
    this.route.data.subscribe(data => {
      this.errorCode = data['errorCode'] || this.errorCode;
      this.errorMessage = data['errorMessage'] || this.errorMessage;
    });
  }

  goBack(): void {
    // Redirect the user based on their authentication status
    if (this.authService.isLoggedIn()) {
      this.router.navigate(['/dashboard']);
    } else {
      this.router.navigate(['/login']);
    }
  }
}
