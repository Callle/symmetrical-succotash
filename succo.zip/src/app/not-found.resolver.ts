// not-found.resolver.ts
import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class NotFoundResolver implements Resolve<any> {
  constructor(private authService: AuthService) {}

  resolve(): any {
    return {
      errorCode: '404',
      errorMessage: 'Page Not Found'
    };
  }
}
