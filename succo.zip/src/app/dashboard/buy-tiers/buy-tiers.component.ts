//buy-tiers.component.ts

import { Component } from '@angular/core';

@Component({
  selector: 'app-buy-tiers',
  templateUrl: './buy-tiers.component.html',
  styleUrls: ['./buy-tiers.component.css']
})
export class BuyTiersComponent {
  tiers = [
    { name: 'BUY TIER 2', heading: 'INSTANT ACCESS TO TIER 2!', description: '9999999999', price: '$22', link: '/purchase/tier2' },
    { name: 'BUY TIER 3', heading: 'INSTANT ACCESS TO TIER 3 and 2!', description: '9999999999', price: '$40', link: '/purchase/tier2' },
    { name: 'BUY TIER 4', heading: 'INSTANT ACCESS TO TIER 4, 3 and 2!', description: '9999999999', price: '$60', link: '/purchase/tier2' },
    { name: 'BUY TIER 5', heading: 'INSTANT ACCESS TO TIER 5, 4, 3 and 2!', description: '9999999999', price: '$80', link: '/purchase/tier2' },
  ];
}
