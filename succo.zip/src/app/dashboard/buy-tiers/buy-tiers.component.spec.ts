import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BuyTiersComponent } from './buy-tiers.component';

describe('BuyTiersComponent', () => {
  let component: BuyTiersComponent;
  let fixture: ComponentFixture<BuyTiersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BuyTiersComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BuyTiersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
