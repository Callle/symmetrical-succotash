import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { animate, state, style, transition, trigger } from '@angular/animations';

interface LogEntry {
  user: string;
  referrer: string;
  totalInvites: number;
  message: string;
  timestamp: string;
}

@Component({
  selector: 'app-referral-log',
  templateUrl: './referral-log.component.html',
  styleUrls: ['./referral-log.component.css'],
  animations: [
    trigger('slideInOut', [
      state('in', style({
        'max-height': '500px', 'opacity': '1', 'visibility': 'visible'
      })),
      state('out', style({
        'max-height': '0px', 'opacity': '0', 'visibility': 'hidden'
      })),
      transition('in => out', animate('400ms ease-in-out')),
      transition('out => in', animate('400ms ease-in-out'))
    ])
  ]
})
export class ReferralLogComponent implements OnInit {

  registrationLog: LogEntry[] = [];
  isExpanded = true;

  constructor(private http: HttpClient) {}
  
  ngOnInit(): void {
    this.fetchRegistrationLog();
  }

  fetchRegistrationLog() {
    this.http.get(`${environment.apiUrl}/registration-log`).subscribe((data: any) => {
      this.registrationLog = data.log;
    });
  }
}
