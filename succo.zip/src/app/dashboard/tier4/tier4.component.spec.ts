import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Tier4Component } from './tier4.component';

describe('Tier4Component', () => {
  let component: Tier4Component;
  let fixture: ComponentFixture<Tier4Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Tier4Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Tier4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
