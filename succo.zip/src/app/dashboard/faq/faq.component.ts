import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../auth.service';
import { UserService } from '../../user.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.css']
})
export class FaqComponent {
  username = '';
  inviteLink = '';
  users: any[] = [];
  tier = 1;
  ip = '';
  totalInvites = 0;
  invitedUsers: any [] = [];
  usersId = ''; 
  
  constructor(private authService: AuthService, private userService: UserService) {}
  
  ngOnInit(): void {
    this.username = this.authService.loggedInUser().username;
    this.generateInviteLink();
  }
  
  generateInviteLink(): void {
   this.userService.generateInviteLink(this.authService.loggedInUser().id).subscribe(
     data => {
       this.inviteLink = data.inviteLink;
     },
     error => {
       console.log('Error', error);
     }
   );
  }
  
  copyInviteLink() {
    navigator.clipboard.writeText(this.inviteLink).then(() => {
      alert('Invite Link copied to clipboard!');
    });
  }
}