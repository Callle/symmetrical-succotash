import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../auth.service';
import { UserService } from '../../user.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent {
  username = '';
  inviteLink = '';
  users: any[] = [];
  tier = 1;
  ip = '';
  totalInvites = 0;
  invitedUsers: any [] = [];
  usersId = ''; 
  
  constructor(
    private authService: AuthService, 
    private userService: UserService, 
    private router: Router, 
    private http: HttpClient) {}
  
  ngOnInit(): void {
    this.username = this.authService.loggedInUser().username;
    this.generateInviteLink();
    this.getDashboardData();
  }
  
  // Add new method
  getDashboardData(): void {
    this.userService.getDashboardData(this.authService.loggedInUser().id).subscribe(
      data => {
        this.tier = data.tier;
        this.totalInvites = data.totalInvites;
        this.invitedUsers = data.invitedUsers;
      },
      error => {
        console.log('Error', error);
      }
    );
  }
  
  generateInviteLink(): void {
   this.userService.generateInviteLink(this.authService.loggedInUser().id).subscribe(
     data => {
       this.inviteLink = data.inviteLink;
     },
     error => {
       console.log('Error', error);
     }
   );
  }
  
  copyInviteLink() {
    navigator.clipboard.writeText(this.inviteLink).then(() => {
      alert('Invite Link copied to clipboard!');
    });
  }
}