// tier2.component.ts

import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../auth.service';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-tier2',
  templateUrl: './tier2.component.html',
  styleUrls: ['./tier2.component.css']
})
export class Tier2Component implements OnInit {
  tier = 1;
  videos: SafeResourceUrl[] = [];

  constructor(private authService: AuthService, private sanitizer: DomSanitizer) {}

  ngOnInit(): void {
    this.authService.getUserTier(this.authService.loggedInUser().id).subscribe(
      tier => {
        this.tier = tier;
        if (this.tier >= 2) {
          this.authService.getVideosForTier(2).subscribe(
            videoUrls => {
              this.videos = this.shuffle(videoUrls).map(url => this.sanitizer.bypassSecurityTrustResourceUrl(url));
            },
            error => console.log('Error', error)
          );
        }
      },
      error => {
        console.log('Error', error);
      }
    );
  }

  shuffle(array: any[]): any[] {
    let currentIndex = array.length, temporaryValue, randomIndex;

    while (0 !== currentIndex) {
      randomIndex = Math.floor(Math.random() * currentIndex);
      currentIndex -= 1;

      temporaryValue = array[currentIndex];
      array[currentIndex] = array[randomIndex];
      array[randomIndex] = temporaryValue;
    }

    return array;
  }
}