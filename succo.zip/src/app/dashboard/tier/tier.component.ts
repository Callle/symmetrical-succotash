// tier.component.ts

import { Component, OnInit, Input } from '@angular/core';
import { AuthService } from '../../auth.service';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-tier',
  templateUrl: './tier.component.html',
  styleUrls: ['./tier.component.css']
})
export class TierComponent implements OnInit {
  @Input()
  tier!: number;
  videos: string[] = [];

  constructor(private authService: AuthService, private http: HttpClient) {}

  ngOnInit(): void {
    this.getVideos();
  }

  getVideos(): void {
    const userId = this.authService.loggedInUser().id;
    this.http.get<any>(`${environment.apiUrl}/videos?userId=${userId}&tier=${this.tier}`).subscribe(
      data => {
        this.videos = data.videos;
      },
      error => {
        console.log('Error', error);
      }
    );
  }
}
