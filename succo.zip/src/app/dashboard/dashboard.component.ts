// dashboard.component.ts

import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { UserService } from '../user.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  username = '';
  inviteLink = '';
  users: any[] = [];
  tier = 1
  totalInvites = 0;
  invitedUsers: any [] = [];
  selectedNavItem = '';

  constructor(
    private authService: AuthService, 
    private userService: UserService, 
    private router: Router, 
    private http: HttpClient) {}

  ngOnInit(): void {
    this.username = this.authService.loggedInUser().username;
    this.generateInviteLink();
    this.getDashboardData();
  }

  // Add new method
  getDashboardData(): void {
    this.userService.getDashboardData(this.authService.loggedInUser().id).subscribe(
      data => {
        this.tier = data.tier;
        this.totalInvites = data.totalInvites;
        this.invitedUsers = data.invitedUsers;
      },
      error => {
        console.log('Error', error);
      }
    );
  }

  generateInviteLink(): void {
    this.userService.generateInviteLink(this.authService.loggedInUser().id).subscribe(
      data => {
        this.inviteLink = data.inviteLink;
      },
      error => {
        console.log('Error', error);
      }
    );
  }

  showContent(navItem: string) {
    this.selectedNavItem = navItem;
  }

  copyInviteLink() {
    navigator.clipboard.writeText(this.inviteLink).then(() => {
      alert('Invite Link copied to clipboard!');
    });
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

}
