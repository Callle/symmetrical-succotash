import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Tier5Component } from './tier5.component';

describe('Tier5Component', () => {
  let component: Tier5Component;
  let fixture: ComponentFixture<Tier5Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Tier5Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Tier5Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
