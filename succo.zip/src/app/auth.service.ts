// auth.service.ts

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map, switchMap } from 'rxjs/operators';
import { environment } from '../environments/environment';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private BASE_URL = environment.apiUrl; // Replace with your backend base URL

  constructor(private http: HttpClient) { }

  login(username: string, password: string): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post(`${this.BASE_URL}/login`, { username, password }, { headers })
      .pipe(catchError(error => throwError(error.error.message || 'Server error')));
  }

  register(username: string, password: string, inviteCode: string, ip: string): Observable<any> {
    return this.http.get<{ip: string}>(environment.ipUrl).pipe(
      switchMap(({ ip }) => {
        const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
        return this.http.post(`${this.BASE_URL}/register`, { username, password, inviteCode, ip }, { headers })
          .pipe(catchError(error => throwError(error.error.message || 'Server error')));
      })
    );
  }
  
  getUserTier(userId: string): Observable<number> {
    return this.http.get<any>(`${this.BASE_URL}/dashboard/${userId}`)
      .pipe(map(response => response.tier));
  }

  getVideosForTier(tier: number): Observable<string[]> {
    return this.http.get<{ videos: string[] }>(`${this.BASE_URL}/videos/${tier}`)
      .pipe(map(response => response.videos));
}

  loggedInUser(): any {
    return JSON.parse(localStorage.getItem('user') || '{}');
  }

  storeUser(user: any): void {
    localStorage.setItem('user', JSON.stringify(user));
  }

  logout() {
    localStorage.clear();
  }

  isLoggedIn(): boolean {
    return !!localStorage.getItem('user');
  }
  
}
