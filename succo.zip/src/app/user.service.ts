// user.service.ts

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private BASE_URL = environment.apiUrl; // Replace with your backend base URL

  constructor(private http: HttpClient) { }

  generateInviteLink(userId: string): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.get(`${this.BASE_URL}/generate-invite-link/${userId}`, { headers });
  }

  getDashboardData(userId: number): Observable<any> {
    return this.http.get(`${this.BASE_URL}/dashboard/${userId}`);
  }

}
