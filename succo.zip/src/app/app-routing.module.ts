// app-routing.module.ts

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
  import { WelcomeComponent } from './dashboard/welcome/welcome.component';
  import { BuyTiersComponent } from './dashboard/buy-tiers/buy-tiers.component';
  import { FaqComponent } from './dashboard/faq/faq.component';
  import { Tier1Component } from './dashboard/tier1/tier1.component';
  import { Tier2Component } from './dashboard/tier2/tier2.component';
  import { Tier3Component } from './dashboard/tier3/tier3.component';
  import { Tier4Component } from './dashboard/tier4/tier4.component';
  import { Tier5Component } from './dashboard/tier5/tier5.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AuthGuard } from './auth.guard';
import { NotFoundComponent } from './not-found/not-found.component';
import { NotFoundResolver } from './not-found.resolver';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  {
    path: 'dashboard',
    component: DashboardComponent,
    canActivate: [AuthGuard],
    children: [
      { path: 'welcome', component: WelcomeComponent, canActivate: [AuthGuard] },
      { path: 'buy-tiers', component: BuyTiersComponent, canActivate: [AuthGuard] },
      { path: 'faq', component: FaqComponent, canActivate: [AuthGuard] },
      { path: 'tier1', component: Tier1Component, canActivate: [AuthGuard] },
      { path: 'tier2', component: Tier2Component, canActivate: [AuthGuard] },
      { path: 'tier3', component: Tier3Component, canActivate: [AuthGuard] },
      { path: 'tier4', component: Tier4Component, canActivate: [AuthGuard] },
      { path: 'tier5', component: Tier5Component, canActivate: [AuthGuard] },
      { path: '', redirectTo: 'welcome', pathMatch: 'full' }, // default child route
    ],
  },
  { path: 'r/:inviteCode', component: RegisterComponent },
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: '**', component: NotFoundComponent, resolve: { url: NotFoundResolver } }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
